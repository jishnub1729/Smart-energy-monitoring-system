source venv/bin/activate
export FLASK_APP=sems.py
export FLASK_DEBUG=True
flask run
